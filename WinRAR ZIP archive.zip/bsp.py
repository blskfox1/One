import asyncio
import logging
import sys
import getpass
from rich import print
from app import (
    clear_console, pinfo, perror, get_config, 
    get_date, save_result_checker, save_result_parser
)

from app.classes import (
    TdataChecker, SessionsChecker, 
    TdataParsing, SessionsParsing, FilesParser
)

sys.setrecursionlimit(100_000)

# Установить уровень логирования
logging.basicConfig(level=logging.CRITICAL)  # Скрыть менее важные логи

TEXT_TYPES_WORK = {
    1: "Выбран тип работы: чек тадат",
    2: "Выбран тип работы: чек .session",
    3: "Выбран тип работы: парсинг тадат",
    4: "Выбран тип работы: парсинг .session",
    5: "Выбран тип работы: парсинг файлов",
}

banner = "\u000d\u000a..."  # Ваш баннер
clear_console()
print(f"[red]{banner}")

def close_program():
    pinfo("Завершение работы")
    getpass.getpass("Нажмите Enter...")
    sys.exit(0)

async def main():
    try:
        pinfo("Запуск главной функции")
        config = get_config()
        if not config:
            close_program()

        TYPE_WORK = config.get("ОСНОВНЫЕ", {}).get("тип_работы")
        if TYPE_WORK not in TEXT_TYPES_WORK:
            perror("Неверный тип работы в конфигурации.")
            close_program()

        pinfo(TEXT_TYPES_WORK[TYPE_WORK])
        pinfo("Подтвердите запуск работы нажатием Enter... ", end="")
        getpass.getpass("")
        date_start = get_date()
        pinfo(f"Дата запуска работы: [#ffffff]{date_start.strftime('%d.%m.%Y %H:%M:%S')}[/#ffffff]")

        # Генерация парсинга или проверки на основе типа работы
        checker_or_parser_mapper = {
            1: (TdataChecker, save_result_checker),
            2: (SessionsChecker, save_result_checker),
            3: (TdataParsing, save_result_parser),
            4: (SessionsParsing, save_result_parser),
            5: (FilesParser, save_result_parser),
        }

        cls, save_function = checker_or_parser_mapper[TYPE_WORK]
        try:
            instance = cls(config)
            result = await instance()

            if result:
                await save_function(config, instance)

        except Exception as e:
            perror(f"При запуске работы, произошла ошибка: {e}")

        finally:
            date_end = get_date()
            pinfo(f"Дата завершения работы: [#ffffff]{date_end.strftime('%d.%m.%Y %H:%M:%S')}[/#ffffff]")
            pinfo(f"Работа выполнена за [#ffffff]{date_end - date_start}[/#ffffff]")

    except Exception as e:
        perror(f"При работе главной функции, произошла ошибка: {e}")

if __name__ == "__main__":
    __version__ = "1.0"
    pinfo(f"Версия: {__version__} Custom")
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("[red]ctrl+c detect...")
    except Exception as e:
        perror(str(e))
    except SystemExit:
        pass
    except:
        print("error", sys.exc_info()[1])
