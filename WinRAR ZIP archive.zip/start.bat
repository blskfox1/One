@echo off
python "bsp.py"
pause